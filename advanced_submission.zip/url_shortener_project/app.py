from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from config import Config
import random
import string
import re

app = Flask(__name__)
app.config.from_object(Config)

db = SQLAlchemy(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"

# ------------------ MODELS ------------------ #

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(9), unique=True, nullable=False)
    password = db.Column(db.String(20), nullable=False)

class URL(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    original_url = db.Column(db.String(500), nullable=False)
    short_url = db.Column(db.String(6), unique=True, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# ------------------ HELPER FUNCTIONS ------------------ #

def generate_short_url():
    return ''.join(random.choices(string.ascii_letters + string.digits, k=6))

def valid_url(url):
    regex = re.compile(
        r'^(https?:\/\/)?'
        r'([\da-z\.-]+)\.([a-z\.]{2,6})'
        r'([\/\w \.-]*)*\/?$'
    )
    return re.match(regex, url)

# ------------------ ROUTES ------------------ #

@app.route("/")
def home():
    return redirect(url_for("login"))

# -------- SIGNUP -------- #
@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        # Username length validation
        if len(username) < 5 or len(username) > 9:
            flash("Username must be between 5 to 9 characters long")
            return redirect(url_for("signup"))

        # Username uniqueness validation
        if User.query.filter_by(username=username).first():
            flash("This username already exists...")
            return redirect(url_for("signup"))

        # Password validation
        if len(password) < 5:
            flash("Password must be at least 5 characters long")
            return redirect(url_for("signup"))

        new_user = User(username=username, password=password)
        db.session.add(new_user)
        db.session.commit()

        flash("Signup successful! Please login.")
        return redirect(url_for("login"))

    return render_template("signup.html")

# -------- LOGIN -------- #
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        user = User.query.filter_by(username=username, password=password).first()

        if user:
            login_user(user)
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid username or password")

    return render_template("login.html")

# -------- DASHBOARD -------- #
@app.route("/dashboard", methods=["GET", "POST"])
@login_required
def dashboard():
    if request.method == "POST":
        original_url = request.form["url"]

        # URL validation
        if not valid_url(original_url):
            flash("Please enter a valid URL")
            return redirect(url_for("dashboard"))

        short_url = generate_short_url()

        url_entry = URL(
            original_url=original_url,
            short_url=short_url,
            user_id=current_user.id
        )

        db.session.add(url_entry)
        db.session.commit()

    urls = URL.query.filter_by(user_id=current_user.id).all()
    return render_template("dashboard.html", urls=urls)

# -------- REDIRECT SHORT URL -------- #
@app.route("/<short_url>")
def redirect_short_url(short_url):
    url = URL.query.filter_by(short_url=short_url).first()
    if url:
        return redirect(url.original_url)
    return "Invalid URL"

# -------- LOGOUT -------- #
@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))

# -------- RUN -------- #
if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
