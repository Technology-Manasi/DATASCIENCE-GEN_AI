from google import genai
from app.config.settings import GEMINI_API_KEY
from app.utils.logger import logger
from app.prompts.system_prompts import SYSTEM_PROMPT


class GeminiService:
    def __init__(self):
        # ✅ New official client
        self.client = genai.Client(api_key=GEMINI_API_KEY)

        # ✅ Latest supported model
        self.model = "gemini-1.5-flash"

    def get_response(self, user_input, history):
        try:
            # Build conversation context
            prompt = SYSTEM_PROMPT + "\n\n"

            for msg in history:
                role = "User" if msg["role"] == "user" else "Assistant"
                prompt += f"{role}: {msg['content']}\n"

            prompt += f"User: {user_input}\nAssistant:"

            response = self.client.models.generate_content(
                model=self.model,
                contents=prompt
            )

            logger.info("Gemini API call successful")

            return response.text

        except Exception as e:
            logger.error(f"Gemini API Error: {e}")
            return "Sorry, I am facing a technical issue. Please try again."