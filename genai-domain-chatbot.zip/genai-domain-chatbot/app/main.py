import streamlit as st
from app.memory.conversation_memory import ConversationMemory
from app.services.gemini_service import GeminiService
from app.ui.chat_ui import render_chat_ui

st.set_page_config(page_title="GenAI Chatbot", layout="centered")

if "memory" not in st.session_state:
    st.session_state.memory = ConversationMemory()

if "gemini" not in st.session_state:
    st.session_state.gemini = GeminiService()

render_chat_ui(
    st.session_state.memory,
    st.session_state.gemini
)