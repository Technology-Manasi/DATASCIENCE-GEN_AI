import streamlit as st

def render_chat_ui(memory, gemini_service):
    st.title("🎓 Career Advisor GenAI Chatbot")

    if st.button("Clear Chat"):
        memory.clear()
        st.experimental_rerun()

    for msg in memory.get_history():
        if msg["role"] == "user":
            st.chat_message("user").write(msg["content"])
        else:
            st.chat_message("assistant").write(msg["content"])

    user_input = st.chat_input("Ask your career question...")

    if user_input:
        memory.add_user_message(user_input)
        st.chat_message("user").write(user_input)

        with st.spinner("Thinking..."):
            response = gemini_service.get_response(
                user_input, memory.get_history()
            )

        memory.add_ai_message(response)
        st.chat_message("assistant").write(response)