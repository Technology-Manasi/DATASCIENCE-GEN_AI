def format_history(history):
    formatted = []
    for chat in history:
        formatted.append({
            "role": chat["role"],
            "parts": [chat["content"]]
        })
    return formatted