import os
from dotenv import load_dotenv

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

if not GEMINI_API_KEY:
    raise ValueError("GEMINI_API_KEY not found in environment variables")