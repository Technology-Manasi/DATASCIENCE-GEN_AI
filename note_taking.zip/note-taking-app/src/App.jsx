import NotesApp from "./components/NotesApp";

function App() {
  return (
    <div className="container">
      <h1>📝 Note Taking Application</h1>
      <NotesApp />
    </div>
  );
}

export default App;
