import { useState } from "react";
import { Trash2, Plus, CheckCircle2, AlertCircle } from "lucide-react";

function NotesApp() {
  const [note, setNote] = useState("");
  const [notes, setNotes] = useState([]);
  const [error, setError] = useState("");

  const addNote = () => {
    if (note.trim() === "") {
      setError("Please enter a note!");
      setTimeout(() => setError(""), 3000);
      return;
    }

    setNotes([...notes, { id: Date.now(), text: note, completed: false }]);
    setNote("");
    setError("");
  };

  const deleteNote = (id) => {
    setNotes(notes.filter((item) => item.id !== id));
  };

  const toggleComplete = (id) => {
    setNotes(
      notes.map((item) =>
        item.id === id ? { ...item, completed: !item.completed } : item
      )
    );
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter") addNote();
  };

  return (
    <div className="notes-wrapper">
      <style>{`
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        .notes-wrapper {
          min-height: 100vh;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
          font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
        }

        .notes-container {
          width: 100%;
          max-width: 500px;
          background: white;
          border-radius: 16px;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
          padding: 30px;
          animation: slideInDown 0.6s cubic-bezier(0.34, 1.56, 0.64, 1);
        }

        @keyframes slideInDown {
          from {
            opacity: 0;
            transform: translateY(-40px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        h1 {
          color: #333;
          text-align: center;
          font-size: 28px;
          margin-bottom: 25px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: fadeInUp 0.7s ease-out 0.1s both;
        }

        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .input-section {
          display: flex;
          gap: 8px;
          margin-bottom: 20px;
          animation: fadeInUp 0.7s ease-out 0.2s both;
        }

        input {
          flex: 1;
          padding: 12px 16px;
          border: 2px solid #e0e0e0;
          border-radius: 10px;
          font-size: 14px;
          transition: all 0.3s ease;
          outline: none;
        }

        input:focus {
          border-color: #667eea;
          box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
          transform: translateY(-2px);
        }

        input::placeholder {
          color: #999;
        }

        button {
          padding: 12px 20px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          border: none;
          border-radius: 10px;
          cursor: pointer;
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 6px;
          transition: all 0.3s ease;
          font-size: 14px;
        }

        button:hover {
          transform: translateY(-3px);
          box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }

        button:active {
          transform: translateY(-1px);
        }

        .error-message {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 12px 14px;
          background: #fee;
          border: 2px solid #ffcccc;
          border-radius: 10px;
          color: #c00;
          margin-bottom: 15px;
          animation: slideInDown 0.4s ease-out;
          font-size: 13px;
        }

        .error-message svg {
          flex-shrink: 0;
        }

        ul {
          list-style: none;
          animation: fadeInUp 0.7s ease-out 0.3s both;
        }

        li {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 14px;
          margin-bottom: 10px;
          background: #f8f9fa;
          border-radius: 10px;
          border-left: 4px solid #667eea;
          transition: all 0.3s ease;
          animation: slideInRight 0.5s ease-out;
        }

        li:hover {
          background: #f0f2f8;
          transform: translateX(4px);
          box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        }

        li.completed {
          opacity: 0.6;
          background: #f0f8f4;
          border-left-color: #10b981;
        }

        li.completed .note-text {
          text-decoration: line-through;
          color: #999;
        }

        @keyframes slideInRight {
          from {
            opacity: 0;
            transform: translateX(-20px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        .note-checkbox {
          background: none;
          border: none;
          cursor: pointer;
          padding: 0;
          display: flex;
          align-items: center;
          transition: all 0.3s ease;
          min-width: 24px;
        }

        .note-checkbox:hover {
          transform: scale(1.15);
        }

        .note-text {
          flex: 1;
          color: #333;
          font-size: 14px;
          word-break: break-word;
          transition: all 0.3s ease;
        }

        .delete-btn {
          padding: 6px 8px;
          background: #ff4757;
          border: none;
          border-radius: 6px;
          color: white;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.3s ease;
          min-width: 36px;
        }

        .delete-btn:hover {
          background: #ff3838;
          transform: scale(1.1) rotate(10deg);
        }

        .empty-state {
          text-align: center;
          padding: 60px 20px;
          color: #999;
          animation: fadeIn 0.6s ease-out;
        }

        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }

        .empty-state-icon {
          font-size: 48px;
          margin-bottom: 12px;
          opacity: 0.4;
        }

        .empty-state p {
          font-size: 14px;
        }

        .stats {
          margin-top: 25px;
          padding-top: 20px;
          border-top: 2px solid #e0e0e0;
          display: flex;
          justify-content: space-around;
          text-align: center;
          animation: fadeInUp 0.7s ease-out 0.4s both;
        }

        .stat {
          flex: 1;
        }

        .stat-number {
          font-size: 22px;
          font-weight: bold;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          display: block;
          margin-bottom: 4px;
        }

        .stat-label {
          font-size: 12px;
          color: #999;
        }
      `}</style>

      <div className="notes-container">
        <h1>📝 My Notes</h1>

        {error && (
          <div className="error-message">
            <AlertCircle size={18} />
            {error}
          </div>
        )}

        <div className="input-section">
          <input
            type="text"
            placeholder="Enter your note"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            onKeyPress={handleKeyPress}
          />
          <button onClick={addNote}>
            <Plus size={18} />
            Add
          </button>
        </div>

        {notes.length === 0 ? (
          <div className="empty-state">
            <div className="empty-state-icon">✨</div>
            <p>No notes yet. Create your first note!</p>
          </div>
        ) : (
          <>
            <ul>
              {notes.map((item) => (
                <li key={item.id} className={item.completed ? "completed" : ""}>
                  <button
                    className="note-checkbox"
                    onClick={() => toggleComplete(item.id)}
                  >
                    <CheckCircle2
                      size={24}
                      color={item.completed ? "#10b981" : "#ddd"}
                      fill={item.completed ? "#10b981" : "none"}
                    />
                  </button>
                  <span className="note-text">{item.text}</span>
                  <button
                    className="delete-btn"
                    onClick={() => deleteNote(item.id)}
                  >
                    <Trash2 size={16} />
                  </button>
                </li>
              ))}
            </ul>

            <div className="stats">
              <div className="stat">
                <div className="stat-number">{notes.length}</div>
                <div className="stat-label">Total</div>
              </div>
              <div className="stat">
                <div className="stat-number">
                  {notes.filter((n) => n.completed).length}
                </div>
                <div className="stat-label">Completed</div>
              </div>
              <div className="stat">
                <div className="stat-number">
                  {notes.filter((n) => !n.completed).length}
                </div>
                <div className="stat-label">Pending</div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default NotesApp;