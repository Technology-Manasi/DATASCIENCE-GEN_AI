# Note Taking Application

This is a simple React-based Note Taking Application with a single Home route.

## Features
- Add notes using input field
- Display notes as an unordered list
- Input validation to prevent empty notes

## How to Run
1. npm install
2. npm start
