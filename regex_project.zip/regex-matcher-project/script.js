function matchRegex() {
const testString = document.getElementById("testString").value;
const pattern = document.getElementById("regexPattern").value;
const flags = document.getElementById("flags").value;
const resultList = document.getElementById("matches");


resultList.innerHTML = "";


try {
const regex = new RegExp(pattern, flags);
const matches = testString.match(regex);


if (matches) {
matches.forEach((match, index) => {
const li = document.createElement("li");
li.textContent = `Match ${index + 1}: ${match}`;
resultList.appendChild(li);
});
} else {
resultList.innerHTML = "<li>No matches found</li>";
}
} catch (error) {
resultList.innerHTML = `<li style="color:red">Invalid Regular Expression</li>`;
}
}