# Regex Matcher Web App


A simple web application inspired by regex101.com.


## Features
- Enter test string
- Enter regex pattern
- Optional regex flags
- Displays all matches
- Error handling for invalid regex


## How to Run
1. Download the project
2. Open `index.html` in your browser


## Sample Regex
- Email: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-z]{2,}`
- Words: `\\b\\w+\\b`